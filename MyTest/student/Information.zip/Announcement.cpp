//
// Created by 22890 on 2025/1/4.
//

#include "Announcement.h"

Announcement::Announcement(Login& login) : login(login){

}

void Announcement::publishAnnouncement(string operation) {
    login.announcement.push_back(operation);
}

std::string Announcement::getCurrentTime() const {
    auto now = chrono::system_clock::now();
    auto now_time_t = chrono::system_clock::to_time_t(now);
    tm tm = *localtime(&now_time_t);

    ostringstream oss;
    oss << put_time(&tm, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

void Announcement::printAnnouncements() const {
    if (login.announcement.empty()) {
        cout << "ϵͳ��δ��������" << endl;
        return;
    }
    cout << "ϵͳ����:" << endl;
    for (const auto& announcement : login.announcement) {
        cout << announcement << endl;
    }

}
